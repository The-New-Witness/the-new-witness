#!/bin/bash
echo 'Deploying to Replit...'