# Notion Embed Card
This is a summary view for Notion vault.