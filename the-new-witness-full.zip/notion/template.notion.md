# Notion Template
Structured Notion vault for The New Witness project.